import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class FlappyWorld extends World
{
    private GreenfootSound backgroundMusic = new GreenfootSound("100 marimba loop.mp3");

    public FlappyWorld(){    
        super(600, 400, 1);
        backgroundMusic.playLoop();  // Reproducir música en bucle
        addObject(new Player(-1.3), 100, 300);
        addObject(new Pipe(), 300, 175);
        addObject(new Pipe(), 600, 175);
        addObject(new Score(), 300, 100); 
    }

    public void gameOver(){
        addObject(new GameOver(), 300, 200);
        backgroundMusic.stop();  // Detener música al morir
    }
}


